def drukuj(a, b="drugi"):
    print(a, b)

drukuj("pierwszy", 'trzeci')