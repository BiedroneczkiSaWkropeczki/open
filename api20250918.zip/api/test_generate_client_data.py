import pytest
from main import generate_client_data

@pytest.fixture
def test_data():
    return {"clientName": 1234, "clientEmail": 1234 }

@pytest.fixture
def client_data():
    return generate_client_data()

def test_generate_client_data_should_return_dictionary(client_data):
    assert isinstance(client_data, dict), f"client_data = {client_data} type should be dict"

def test_generate_client_data_client_name_should_be_str(client_data):
    assert isinstance(client_data['clientName'], str), f"clientName = {client_data['clientName']} type should be str"

def test_generate_client_data_client_email_is_correct(client_data):
    assert '@' in client_data['clientEmail']

def test_generate_client_data_should_return_dictionary_with_values(client_data):
    for value in client_data.values():
        assert isinstance(value, str), f"{value} is not string"
