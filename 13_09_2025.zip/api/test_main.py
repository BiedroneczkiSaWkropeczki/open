from main import get_request


def nazwa():
    assert 2 + 2 == 4

def test_addition():
    assert 2 + 2 == 4
    assert 4 + 2 == 6 
    assert 10 + 5 == 15

def test_get_request():
    assert get_request('https://simple-books-api.glitch.me') == 200
    assert get_request('https://simple-books-api.glitch.me/123456') == 404
    # Wykonaj żadanie, i spodziewaj się że kod odpowiedzi wynosi 200
