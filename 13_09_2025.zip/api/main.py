import requests


def get_request(url):
    headers = {'Content-Type': 'text/plain'}
    response = requests.request("GET", url, headers=headers)
    return response.status_code
