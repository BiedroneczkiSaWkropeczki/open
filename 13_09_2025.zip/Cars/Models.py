from .Cars import Car, Vehicle, ElectricCar

my_car1 = Car('Skoda', 'Octavia')
my_car2 = Vehicle('Skoda', 'Fabia', 'Gas')
my_car3 = ElectricCar('Tesla', 'S', '78')