client_data = {"clientName": 'name',
                "clientEmail": 'email'
                }

for i in client_data.items():
    print(i)